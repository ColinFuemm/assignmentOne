import pytest
import System

#Tests if the program will login
def test_login(grading_system):
    username = 'cmhbf5'
    password =  'bestTA'
    grading_system.login(username,password)


@pytest.fixture
def grading_system():
    gradingSystem = System.System()
    gradingSystem.load_data()
    return gradingSystem
