# Exercises
1. Perform steps outlined in assignment 7.1, in the [README.md](./README.md) file in this directory. 
2. Participate in the Slack Channel on Construction and Testing, helping your course mates when they get "stuck", or soliciting mutual aid when you are "stuck". (This is the "Construction and Testing Assignment in Canvas")
3. This module will extend two weeks and have a deployment component with an assignment due date after the testing assignment. You will be assigned to teams for this part of the module. 